    function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
// Variáveis globais
let plants = [];
let weeds = [];
let score = 0;
let plantTime = 0;
let weedTime = 0;
let weedInterval = 500; // Intervalo inicial para o aparecimento das ervas daninhas
let plantSound, removeSound, weedSound;

function preload() {
  plantSound = loadSound('plant.mp3');
  removeSound = loadSound('remove.mp3');
  weedSound = loadSound('weed.mp3');
}

function setup() {
  createCanvas(600, 400);
  frameRate(30);
  textSize(18);
  textAlign(CENTER, CENTER);
}

function draw() {
  background(200, 255, 200);
  drawGrid();
  drawPlants();
  drawWeeds();
  drawScore();
  updateTimers();
  updateDifficulty();
}

function drawGrid() {
  stroke(0);
  for (let x = 0; x < width; x += 40) {
    for (let y = 0; y < height; y += 40) {
      noFill();
      rect(x, y, 40, 40);
    }
  }
}

function drawPlants() {
  for (let p of plants) {
    fill(34, 139, 34);
    ellipse(p.x * 40 + 20, p.y * 40 + 20, 30, 30);
  }
}

function drawWeeds() {
  for (let w of weeds) {
    fill(0, 128, 0);
    ellipse(w.x * 40 + 20, w.y * 40 + 20, 20 + score / 10, 20 + score / 10);
  }
}

function drawScore() {
  fill(0);
  text('Pontuação: ' + score, width - 100, 30);
}

function updateTimers() {
  plantTime++;
  weedTime++;
  if (plantTime > 300) {
    plantTime = 0;
    if (plants.length > 0) {
      plants.splice(0, 1);
      score--;
    }
  }
  if (weedTime > weedInterval) {
    weedTime = 0;
    let x = floor(random(15));
    let y = floor(random(10));
    weeds.push(createVector(x, y));
    weedSound.play();
    score -= 2;
  }
}

function updateDifficulty() {
  if (score > 50 && weedInterval > 100) {
    weedInterval -= 50;
  }
}

function keyPressed() {
  if (key === ' ') {
    let x = floor(mouseX / 40);
    let y = floor(mouseY / 40);
    if (!isOccupied(x, y)) {
      plants.push(createVector(x, y));
      score++;
      plantSound.play();
    }
  } else if (key === 'R' || key === 'r') {
    let x = floor(mouseX / 40);
    let y = floor(mouseY / 40);
    for (let i = plants.length - 1; i >= 0; i--) {
      if (plants[i].x === x && plants[i].y === y) {
        plants.splice(i, 1);
        score--;
        removeSound.play();
        break;
      }
    }
  }
}

function isOccupied(x, y) {
  for (let p of plants) {
    if (p.x === x && p.y === y) {
      return true;
    }
  }
  for (let w of weeds) {
    if (w.x === x && w.y === y) {
      return true;
    }
  }
  return false;
}
